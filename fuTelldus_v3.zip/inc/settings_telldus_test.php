<?php
	
	echo "<h4>Usersettings</h4>";

	echo "<p>You need to set the Public key and privte key in your userprofile to get access.</p>";


	echo "<ul>";
		echo "<li><a href='?page=settings&view=telldus_test_connect'>Userlogin</a></li>";
		echo "<li><a href='?page=settings&view=telldus_test_api'>API connect</a></li>";
	echo "</ul>";


?>